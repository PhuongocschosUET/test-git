#include<bits/stdc++.h>
using namespace std;
/*
int GCD(int a, int b) {
    if( a==0 or b==0) return a+b;
    while(a!=b) {
        if(a>b){
            a=a-b;
        }
        else {
            b=b-a;
        }
    }
    return a;
}
*/
int GCD(int a,int b)
{
    if (b==0) return a;
    else return GCD(b,a%b);
}
int main () {
    int a,b;
    cin>>a>>b;
    int m=GCD(a,b);
    cout<<m;
}
